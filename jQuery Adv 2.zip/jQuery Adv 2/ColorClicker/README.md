ColorClicker
============

ColorClicker Assignment for jQuery
